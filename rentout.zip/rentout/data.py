users = [
    (1, 'Zara', 'zara@gmail.com', 'zara','9239492934','T.mail Balaji, karur'),
    (2, 'Zara2', 'zara2@gmail.com', 'zara2','9482376234','vadakari street, salem'),
    (3, 'Zara3', 'zara3@gmail.com', 'zara3','9838372938','street of majestic, yercaud')
]
products=[
	(1,'jacket-1','/static/assets/images/products/jacket-1.jpg',1),
	(2,'shoe-4','/static/assets/images/products/shoe-4.jpg',1),
	(3,'watch-3','/static/assets/images/products/watch-3.jpg',1),
	(4,'home-1','/static/assets/images/products/home-1.jpg',1),
	(5,'bicycle','/static/assets/images/products/bicycle.jpg',2),
	(6,'shoe-1','/static/assets/images/products/shoe-1.jpg',2),
	(7,'bed','/static/assets/images/products/bed.jpg',2),
	(8,'home-3','/static/assets/images/products/home-3.jpg',2),
	(9,'jwelleryset','/static/assets/images/products/jwelleryset.jpg',3),
	(10,'suit','/static/assets/images/products/suit.jpg',3),
	(11,'party-wear-1','/static/assets/images/products/party-wear-1.jpg',3),
	(12,'home-5','/static/assets/images/products/home-5.jpg',3)
]
